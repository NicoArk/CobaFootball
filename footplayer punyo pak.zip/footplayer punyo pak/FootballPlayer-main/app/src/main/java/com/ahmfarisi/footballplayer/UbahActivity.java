package com.ahmfarisi.footballplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UbahActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah);
    }
}